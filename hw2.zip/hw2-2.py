import argparse
import os 
import sys
import zipfile

parser=argparse.ArgumentParser(prog="hw2-2.py",description="unzip til secret be gotten")
parser.add_argument("string", type=str, nargs='+')


arg=parser.parse_args()

t=arg.string[0]
r=arg.string[1]

visited=[]

def unzipper(current_dir,r,visited):

    k1=os.listdir(current_dir)
       
        
    
    
    for f in k1:
        if f=="secret.txt":
            with open(f"{current_dir}/{f}","r") as fil:
                
                with open(r,"w") as dest:
                    ll=fil.read()
                    dest.write(ll)
                    
                    
        elif os.path.isfile(f"{current_dir}/{f}") and f.endswith("txt"):
            if f"{current_dir}/{f}" not in visited:
                with open(f"{current_dir}/{f}","r") as fil:
                    c=fil.read()
                visited.append(f"{current_dir}/{f}")
                
                for j in k1:
                    if j.endswith("zip"):#zipfile.is_zipfile(j):                       
                        if f"{current_dir}/{j}" not in visited:
                            visited.append(f"{current_dir}/{j}")
                            
                            with zipfile.ZipFile(f'{current_dir}/{j}', 'r') as zf:
                                zf.extractall(path=current_dir, pwd=f"{c}".encode())
                                    
                                zf.close()
                                unzipper(current_dir,r,visited)
        
            
            
unzipper(t,r,visited)