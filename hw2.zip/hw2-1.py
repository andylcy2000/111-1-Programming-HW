import argparse
import os 
import sys

parser=argparse.ArgumentParser(prog="hw2-1.py",description="program to concatenates files in directories")

parser.add_argument("-t",type=str,default="./testcase00/",help="path of target testcase directory (default: ./testcase00/)")
parser.add_argument("-r",type=str,required=True,help="path of result file (default:None)")
parser.add_argument("-s",type=str,required=True,help="searching algorithm with option ['bfs'|'dfs'] (default:None)")

arg=parser.parse_args()

def output_format(order,content):
    return "({:3d}){}\n".format(order,content)

def dfs(t,r):
    # you can change the return value and parameters of function as you want.
    # for each file you found, your output should follow format as output_format(order,content_you_read_from_file).
    # you can also check the format by comparing your ans.txt with ans.txt in ./sample_ans/
    # TO DO: find all txt file in dir, concatenate their contents, save them in ans.txt
    count=1
    stack=[]
    flist=os.listdir(t)
    flist.sort(reverse=True)
    for i in flist:
        if i!=".ipynb_checkpoints":
            stack.append(i)
    while(len(stack)>0):
        
        get=stack.pop(-1)
        if os.path.isfile(f"{t}/{get}"):
            count+=1
            with open(f"{t}/{get}","r") as ll:
                content=ll.read()
            with open(f"{r}","a") as f:
                k=t+"/"+get
                f.write(output_format(count,content)) 
        else:
            dlist=os.listdir(f"{t}/{get}")
            count+=1
            dlist.sort(reverse=True)
            for j in dlist:
                if j!=".ipynb_checkpoints":
                    p=get+"/"+j
                    stack.append(p)

def bfs(t,r):
    count=1
    # TO DO
    queue=[]
    flist=os.listdir(t)
    flist.sort()
    for i in flist:
        if i!=".ipynb_checkpoints":
            queue.append(i)
        
    while(len(queue)>0):
        count+=1
        get=queue.pop(0)
        if os.path.isfile(f"{t}/{get}"):
            with open(f"{t}/{get}","r") as ll:
                content=ll.read()
            with open(f"{r}","a") as f:
                f.write(output_format(count,content))
                
        else:
            dlist=os.listdir(f"{t}/{get}")
            dlist.sort()
            for j in dlist:
                if j!=".ipynb_checkpoints":
                    p=get+"/"+j
                    queue.append(p)
                
if arg.s==("bfs"):
    bfs(arg.t,arg.r)
    
elif arg.s==("dfs"):
    dfs(arg.t,arg.r)


    